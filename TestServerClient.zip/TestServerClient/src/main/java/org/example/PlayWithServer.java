package org.example;

import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.IllegalFormatException;
import java.util.Random;

public class PlayWithServer extends Thread{
    private int ClientNbre;
    private int SecretNbre;
    private boolean fin;
    private String Winner;
    public static void main(String[] args) {
        new PlayWithServer().start();
    }

    @Override
    public void run(){
        try {
            ServerSocket ss=new ServerSocket(12345);
            SecretNbre = new Random().nextInt(100);
            System.out.println(SecretNbre);
            System.out.println("Le serveur essaie de démarrer ....");
            while(true){
                Socket s=ss.accept();
                ++ClientNbre;
                new Communication(s,ClientNbre).start();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public class Communication extends Thread {
        private Socket s;
        private int ClientNumber;
        Communication(Socket s,int ClientNumber){
            this.s=s;
            this.ClientNumber=ClientNumber;
        }
        @Override
        public void run(){
            try {
                InputStream is = s.getInputStream();
                InputStreamReader isr=new InputStreamReader(is);
                BufferedReader br= new BufferedReader(isr);
                OutputStream os = s.getOutputStream();
                String Ip = s.getRemoteSocketAddress().toString();
                System.out.println("Le client numéro"+ClientNbre+"et son IP "+Ip);
                PrintWriter pw=new PrintWriter(os,true);
                pw.println("Vous etes le client "+ClientNumber);
                pw.println("Devinez le nombre secret ....");

                while(true){
                    String UserRequest = br.readLine();
                    boolean RequestFormat=false;
                    int UserNbre=0;
                    try {
                         UserNbre = Integer.parseInt(UserRequest);
                        RequestFormat = true;
                    }catch(NumberFormatException e){
                        pw.println("Entrer un nombre ");
                    }
                    if(RequestFormat){
                        System.out.println("le client "+ClientNbre+" a envoyé le nombre "+UserNbre);
                        if(!fin){
                            if(UserNbre>SecretNbre) pw.println("Votre nombre est supérieur au nombre secret");
                            else if(UserNbre<SecretNbre) pw.println("Votre nombre est inferieur au nombre secret");
                            else{
                                pw.println("Tu as bien répondu");
                                System.out.println("Le gagnant est le client numéro "+ClientNbre+" et son IP "+Ip);
                                fin = true;
                            }
                        }
                        else{
                            pw.println("On a terminé .... et qui a gagné est le client "+ ClientNbre);
                        }}



                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}
