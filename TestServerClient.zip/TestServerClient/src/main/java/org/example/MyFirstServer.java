package org.example;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.ServerSocket;
import java.net.Socket;

public class MyFirstServer {
    public static void main(String[] args) throws Exception {
        ServerSocket ss= new ServerSocket(123);
        System.out.println("Server Connected");
        Socket s= ss.accept();
        InputStream is= s.getInputStream();
        OutputStream os= s.getOutputStream();
        String address= s.getRemoteSocketAddress().toString();
        System.out.println("Entrer un nombre"+address);
        int number = is.read();
        System.out.println("Nombre entrée : "+ number);
        int calc = number * 5;
        System.out.println("Envoi de réponse "+ calc);
        os.write(calc);
        s.close();

    }
}
