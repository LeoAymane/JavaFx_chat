package org.example;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;
import java.util.Scanner;

public class MyFirstClient {
    public static void main(String[] args) throws Exception {
        System.out.println("Se connecter au serveur");
        Socket s= new Socket("localhost",1234);
        InputStream is=s.getInputStream();
        OutputStream os=s.getOutputStream();
        Scanner sc = new Scanner(System.in);
        System.out.println("Entrer un nombre");
        int nbre=sc.nextInt();
        System.out.println("Envoi du nombre au serveur "+nbre);
        os.write(nbre);
        System.out.println("Attente de la réponse serveur");
        int rep=is.read();
        System.out.println("La réponse du serveur est: "+rep);


    }
}
